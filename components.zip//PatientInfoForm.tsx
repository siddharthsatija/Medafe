import { useState } from 'react';
import { Minus, Plus, Share2, Star, MoreVertical, Droplet, Pill, Heart, ChevronLeft, CheckCircle2, Send, Paperclip, Mic } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';

type FormStep = 'patient-info' | 'selection' | 'medicine' | 'lifestyle' | 'chatbot';

export function PatientInfoForm() {
  const [currentStep, setCurrentStep] = useState<FormStep>('patient-info');
  const [selectedOption, setSelectedOption] = useState<'medicine' | 'lifestyle' | null>(null);
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'bot', message: string }>>([]);
  const [chatInput, setChatInput] = useState('');
  
  const [formData, setFormData] = useState({
    symptoms: '',
    symptomDuration: 1,
    symptomUnit: 'days',
    mealsPerDay: 0,
    waterIntake: 0,
    lastMeal: '',
    selectedFoods: [] as string[],
    additionalInfo: '',
    // Medicine Information
    currentMedications: '',
    allergies: '',
    medicationFrequency: 'daily',
    // Lifestyle Guidance
    exerciseFrequency: 'never',
    sleepHours: 7,
    stressLevel: 'moderate',
    smokingStatus: 'non-smoker',
    alcoholConsumption: 'none'
  });

  const handleIncrement = (field: 'symptomDuration' | 'mealsPerDay') => {
    setFormData(prev => ({ ...prev, [field]: prev[field] + 1 }));
  };

  const handleDecrement = (field: 'symptomDuration' | 'mealsPerDay') => {
    setFormData(prev => ({ ...prev, [field]: Math.max(0, prev[field] - 1) }));
  };

  const getMealCardColor = () => {
    if (formData.mealsPerDay === 0) {
      return 'bg-gradient-to-br from-gray-400 to-gray-500';
    } else if (formData.mealsPerDay === 1) {
      return 'bg-gradient-to-br from-red-500 to-red-600';
    } else if (formData.mealsPerDay === 2) {
      return 'bg-gradient-to-br from-orange-500 to-orange-600';
    } else {
      return 'bg-gradient-to-br from-emerald-500 to-emerald-600';
    }
  };

  const foodOptions = [
    { name: 'Eggs', emoji: '🥚' },
    { name: 'Juice', emoji: '🧃' },
    { name: 'Sandwich', emoji: '🥪' },
    { name: 'Salad', emoji: '🥗' },
    { name: 'Rice', emoji: '🍚' },
    { name: 'Pasta', emoji: '🍝' },
    { name: 'Soup', emoji: '🍲' },
    { name: 'Fruits', emoji: '🍎' },
    { name: 'Coffee', emoji: '☕' },
  ];

  const toggleFood = (foodName: string) => {
    setFormData(prev => {
      const isSelected = prev.selectedFoods.includes(foodName);
      if (isSelected) {
        return { ...prev, selectedFoods: prev.selectedFoods.filter(f => f !== foodName) };
      } else {
        return { ...prev, selectedFoods: [...prev.selectedFoods, foodName] };
      }
    });
  };

  const handleNext = () => {
    if (currentStep === 'patient-info' && selectedOption) {
      if (selectedOption === 'medicine') {
        // Go directly to chatbot for medicine
        const greeting = "Hello! I'm here to help you with your medicine information. Please tell me about your current medications, allergies, or any questions you have about your prescriptions.";
        setChatMessages([{ role: 'bot', message: greeting }]);
        setCurrentStep('chatbot');
      } else if (selectedOption === 'lifestyle') {
        // Show lifestyle form first
        setCurrentStep('lifestyle');
      }
    }
  };

  const handleContinueToChatbot = () => {
    // Initialize chatbot with a greeting based on selection
    const greeting = selectedOption === 'medicine' 
      ? "Hello! I'm here to help you with your medicine information. Please tell me about your current medications, allergies, or any questions you have about your prescriptions."
      : "Hello! I'm here to discuss your lifestyle habits. Feel free to share about your exercise routine, sleep patterns, diet, or any health goals you'd like to work on.";
    
    setChatMessages([{ role: 'bot', message: greeting }]);
    setCurrentStep('chatbot');
  };

  const handleBack = () => {
    if (currentStep === 'chatbot') {
      // Go back based on selection
      if (selectedOption === 'medicine') {
        // Medicine goes back to patient info
        setCurrentStep('patient-info');
      } else if (selectedOption === 'lifestyle') {
        // Lifestyle goes back to lifestyle form
        setCurrentStep('lifestyle');
      }
      setChatMessages([]);
      setChatInput('');
    } else if (currentStep === 'lifestyle') {
      setCurrentStep('patient-info');
    } else if (currentStep === 'selection') {
      setCurrentStep('patient-info');
    }
  };

  const handleSendMessage = () => {
    if (chatInput.trim() === '') return;

    // Add user message
    const newMessages = [...chatMessages, { role: 'user' as const, message: chatInput }];
    setChatMessages(newMessages);
    setChatInput('');

    // Simulate bot response
    setTimeout(() => {
      let botResponse = '';
      
      if (selectedOption === 'medicine') {
        const responses = [
          "Thank you for sharing that information. Do you experience any side effects from your current medications?",
          "I understand. How long have you been taking this medication?",
          "That's helpful to know. Are there any allergies or adverse reactions I should be aware of?",
          "I see. Do you take your medications at specific times during the day?",
        ];
        botResponse = responses[Math.floor(Math.random() * responses.length)];
      } else {
        const responses = [
          "That's great! How do you feel after your exercise sessions?",
          "Interesting. Have you noticed any changes in your energy levels?",
          "I appreciate you sharing that. What time do you usually go to bed?",
          "That's helpful information. Do you have any specific health goals you're working towards?",
        ];
        botResponse = responses[Math.floor(Math.random() * responses.length)];
      }

      setChatMessages(prev => [...prev, { role: 'bot', message: botResponse }]);
    }, 800);
  };

  const handleSubmit = () => {
    console.log('Form submitted:', { ...formData, chatMessages });
    // Handle form submission
  };

  // Render Chatbot UI
  if (currentStep === 'chatbot') {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleBack}
              className={selectedOption === 'medicine' ? 'text-blue-700 hover:text-blue-900 hover:bg-blue-100' : 'text-teal-700 hover:text-teal-900 hover:bg-teal-100'}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              {selectedOption === 'medicine' ? (
                <>
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <Pill className="w-5 h-5 text-white" />
                  </div>
                  <h1 className="text-blue-900">Medicine Assistant</h1>
                </>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center">
                    <Heart className="w-5 h-5 text-white" />
                  </div>
                  <h1 className="text-teal-900">Lifestyle Coach</h1>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Chat Container */}
        <div className={`bg-white rounded-3xl shadow-lg border-2 ${selectedOption === 'medicine' ? 'border-blue-200' : 'border-teal-200'} overflow-hidden`}>
          {/* Chat Messages */}
          <div className="h-[500px] overflow-y-auto p-6 space-y-4">
            {chatMessages.map((msg, index) => (
              <div 
                key={index}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === 'user' 
                    ? selectedOption === 'medicine'
                      ? 'bg-blue-500 text-white'
                      : 'bg-teal-500 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  {msg.message}
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className={`border-t-2 ${selectedOption === 'medicine' ? 'border-blue-200' : 'border-teal-200'} p-4`}>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className={`${selectedOption === 'medicine' ? 'border-blue-300 text-blue-600 hover:bg-blue-50 hover:text-blue-700' : 'border-teal-300 text-teal-600 hover:bg-teal-50 hover:text-teal-700'}`}
              >
                <Paperclip className="w-5 h-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className={`${selectedOption === 'medicine' ? 'border-blue-300 text-blue-600 hover:bg-blue-50 hover:text-blue-700' : 'border-teal-300 text-teal-600 hover:bg-teal-50 hover:text-teal-700'}`}
              >
                <Mic className="w-5 h-5" />
              </Button>
              <Input
                placeholder="Type your message..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className={`flex-1 ${selectedOption === 'medicine' ? 'border-blue-300 focus:border-blue-500 focus:ring-blue-500' : 'border-teal-300 focus:border-teal-500 focus:ring-teal-500'}`}
              />
              <Button
                onClick={handleSendMessage}
                className={selectedOption === 'medicine' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-teal-600 hover:bg-teal-700'}
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render Selection Screen
  if (currentStep === 'selection') {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleBack}
              className="text-blue-700 hover:text-blue-900 hover:bg-blue-100"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-blue-900">Choose Additional Information</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto mt-12">
          {/* Medicine Information Card */}
          <button
            onClick={() => setSelectedOption(prev => prev === 'medicine' ? null : 'medicine')}
            className={`p-8 rounded-3xl border-2 transition-all duration-300 text-left ${
              selectedOption === 'medicine'
                ? 'border-blue-500 bg-blue-50 shadow-lg scale-105'
                : 'border-blue-200 bg-white hover:border-blue-300 hover:shadow-md'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Pill className={`w-8 h-8 ${selectedOption === 'medicine' ? 'text-white' : 'text-blue-600'}`} />
                {selectedOption === 'medicine' && (
                  <CheckCircle2 className="w-6 h-6 text-white" />
                )}
              </div>
            </div>
            <h2 className="text-blue-900 mb-2">Medicine Information</h2>
            <p className="text-blue-700">
              Provide details about current medications, dosage, allergies, and prescription history
            </p>
          </button>

          {/* Lifestyle Guidance Card */}
          <button
            onClick={() => setSelectedOption(prev => prev === 'lifestyle' ? null : 'lifestyle')}
            className={`p-8 rounded-3xl border-2 transition-all duration-300 text-left ${
              selectedOption === 'lifestyle'
                ? 'border-teal-500 bg-teal-50 shadow-lg scale-105'
                : 'border-teal-200 bg-white hover:border-teal-300 hover:shadow-md'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center">
                <Heart className={`w-8 h-8 ${selectedOption === 'lifestyle' ? 'text-white' : 'text-teal-600'}`} />
                {selectedOption === 'lifestyle' && (
                  <CheckCircle2 className="w-6 h-6 text-white" />
                )}
              </div>
            </div>
            <h2 className="text-teal-900 mb-2">Lifestyle Guidance</h2>
            <p className="text-teal-700">
              Share information about exercise habits, sleep patterns, stress levels, and daily routines
            </p>
          </button>
        </div>

        <div className="mt-8 flex justify-center">
          <Button 
            size="lg" 
            className="bg-blue-600 text-white hover:bg-blue-700 px-12"
            onClick={handleNext}
            disabled={!selectedOption}
          >
            Continue
          </Button>
        </div>
      </div>
    );
  }

  // Render Medicine Information Form
  if (currentStep === 'medicine') {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleBack}
              className="text-blue-700 hover:text-blue-900 hover:bg-blue-100"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-blue-900">Medicine Information</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Current Medications */}
          <div className="md:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-blue-100">
            <label className="block mb-3 text-blue-900">
              Current Medications
            </label>
            <Textarea
              placeholder="List all medications you're currently taking..."
              value={formData.currentMedications}
              onChange={(e) => setFormData(prev => ({ ...prev, currentMedications: e.target.value }))}
              className="min-h-[120px] resize-none border-blue-200 focus:border-blue-400 focus:ring-blue-400"
            />
          </div>

          {/* Allergies */}
          <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl p-6 shadow-sm border border-red-200">
            <label className="block mb-3 text-red-900">
              Known Allergies
            </label>
            <Textarea
              placeholder="List any medication or food allergies..."
              value={formData.allergies}
              onChange={(e) => setFormData(prev => ({ ...prev, allergies: e.target.value }))}
              className="min-h-[100px] resize-none border-red-200 focus:border-red-400 focus:ring-red-400"
            />
          </div>

          {/* Medication Frequency */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 shadow-sm border border-blue-200">
            <label className="block mb-3 text-blue-900">
              How often do you take medications?
            </label>
            <Select
              value={formData.medicationFrequency}
              onValueChange={(value) => setFormData(prev => ({ ...prev, medicationFrequency: value }))}
            >
              <SelectTrigger className="border-blue-300 focus:border-blue-500 focus:ring-blue-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="as-needed">As Needed</SelectItem>
                <SelectItem value="none">None</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <Button 
            variant="outline"
            size="lg" 
            className="px-8"
            onClick={handleBack}
          >
            Back
          </Button>
          <Button 
            size="lg" 
            className="bg-blue-600 text-white hover:bg-blue-700 px-8"
            onClick={handleContinueToChatbot}
          >
            Continue to Chat
          </Button>
        </div>
      </div>
    );
  }

  // Render Lifestyle Guidance Form
  if (currentStep === 'lifestyle') {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleBack}
              className="text-teal-700 hover:text-teal-900 hover:bg-teal-100"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-teal-900">Lifestyle Guidance</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Exercise Frequency */}
          <div className="bg-gradient-to-br from-teal-50 to-cyan-50 rounded-2xl p-6 shadow-sm border border-teal-200">
            <label className="block mb-3 text-teal-900">
              Exercise Frequency
            </label>
            <Select
              value={formData.exerciseFrequency}
              onValueChange={(value) => setFormData(prev => ({ ...prev, exerciseFrequency: value }))}
            >
              <SelectTrigger className="border-teal-300 focus:border-teal-500 focus:ring-teal-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="never">Never</SelectItem>
                <SelectItem value="rarely">Rarely (1-2 times/month)</SelectItem>
                <SelectItem value="sometimes">Sometimes (1-2 times/week)</SelectItem>
                <SelectItem value="regularly">Regularly (3-4 times/week)</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Sleep Hours */}
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-6 shadow-sm border border-indigo-200">
            <label className="block mb-3 text-indigo-900">
              Average Sleep Hours
            </label>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setFormData(prev => ({ ...prev, sleepHours: Math.max(0, prev.sleepHours - 1) }))}
                className="h-9 w-9 border-indigo-300 text-indigo-700 hover:bg-indigo-100"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                type="number"
                value={formData.sleepHours}
                onChange={(e) => setFormData(prev => ({ ...prev, sleepHours: parseInt(e.target.value) || 0 }))}
                className="text-center h-9 border-indigo-300 focus:border-indigo-500 focus:ring-indigo-500"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => setFormData(prev => ({ ...prev, sleepHours: Math.min(24, prev.sleepHours + 1) }))}
                className="h-9 w-9 border-indigo-300 text-indigo-700 hover:bg-indigo-100"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-indigo-600 mt-2">{formData.sleepHours} hours per night</p>
          </div>

          {/* Stress Level */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 shadow-sm border border-amber-200">
            <label className="block mb-3 text-amber-900">
              Current Stress Level
            </label>
            <Select
              value={formData.stressLevel}
              onValueChange={(value) => setFormData(prev => ({ ...prev, stressLevel: value }))}
            >
              <SelectTrigger className="border-amber-300 focus:border-amber-500 focus:ring-amber-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="moderate">Moderate</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="very-high">Very High</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Smoking Status */}
          <div className="bg-gradient-to-br from-slate-50 to-gray-50 rounded-2xl p-6 shadow-sm border border-slate-200">
            <label className="block mb-3 text-slate-900">
              Smoking Status
            </label>
            <Select
              value={formData.smokingStatus}
              onValueChange={(value) => setFormData(prev => ({ ...prev, smokingStatus: value }))}
            >
              <SelectTrigger className="border-slate-300 focus:border-slate-500 focus:ring-slate-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="non-smoker">Non-Smoker</SelectItem>
                <SelectItem value="former-smoker">Former Smoker</SelectItem>
                <SelectItem value="occasional">Occasional Smoker</SelectItem>
                <SelectItem value="regular">Regular Smoker</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Alcohol Consumption */}
          <div className="md:col-span-2 bg-gradient-to-br from-rose-50 to-pink-50 rounded-2xl p-6 shadow-sm border border-rose-200">
            <label className="block mb-3 text-rose-900">
              Alcohol Consumption
            </label>
            <Select
              value={formData.alcoholConsumption}
              onValueChange={(value) => setFormData(prev => ({ ...prev, alcoholConsumption: value }))}
            >
              <SelectTrigger className="border-rose-300 focus:border-rose-500 focus:ring-rose-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="occasional">Occasional (1-2 drinks/month)</SelectItem>
                <SelectItem value="moderate">Moderate (1-2 drinks/week)</SelectItem>
                <SelectItem value="regular">Regular (3-4 drinks/week)</SelectItem>
                <SelectItem value="frequent">Frequent (5+ drinks/week)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <Button 
            variant="outline"
            size="lg" 
            className="px-8"
            onClick={handleBack}
          >
            Back
          </Button>
          <Button 
            size="lg" 
            className="bg-teal-600 text-white hover:bg-teal-700 px-8"
            onClick={handleContinueToChatbot}
          >
            Continue to Chat
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-purple-700 font-bold">Medsafe</h1>
        <div className="flex items-center gap-4">
        </div>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 auto-rows-fr">
        {/* Symptoms - Large Card */}
        <div className="md:col-span-2 lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-blue-100">
          <label className="block mb-3 text-blue-900">
            What symptoms are you experiencing? <span className="text-red-500">*</span>
          </label>
          <Textarea
            placeholder="e.g., headache, fever, cough, fatigue..."
            value={formData.symptoms}
            onChange={(e) => setFormData(prev => ({ ...prev, symptoms: e.target.value }))}
            className="min-h-[120px] resize-none border-blue-200 focus:border-blue-400 focus:ring-blue-400"
          />
        </div>

        {/* Symptom Duration - Medium Card */}
        <div className="bg-gradient-to-br from-teal-50 to-cyan-50 rounded-2xl p-6 shadow-sm border border-teal-200">
          <label className="block mb-3 text-teal-900">
            Since when have you been experiencing these symptoms? <span className="text-red-500">*</span>
          </label>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 flex-1">
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleDecrement('symptomDuration')}
                className="h-9 w-9 border-teal-300 text-teal-700 hover:bg-teal-100 hover:text-teal-900"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                type="number"
                value={formData.symptomDuration}
                onChange={(e) => setFormData(prev => ({ ...prev, symptomDuration: parseInt(e.target.value) || 0 }))}
                className="text-center h-9 border-teal-300 focus:border-teal-500 focus:ring-teal-500"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleIncrement('symptomDuration')}
                className="h-9 w-9 border-teal-300 text-teal-700 hover:bg-teal-100 hover:text-teal-900"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <Select
              value={formData.symptomUnit}
              onValueChange={(value) => setFormData(prev => ({ ...prev, symptomUnit: value }))}
            >
              <SelectTrigger className="w-[110px] border-teal-300 focus:border-teal-500 focus:ring-teal-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hours">hours</SelectItem>
                <SelectItem value="days">days</SelectItem>
                <SelectItem value="weeks">weeks</SelectItem>
                <SelectItem value="months">months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Meals Per Day - Medium Card */}
        <div className={`${getMealCardColor()} rounded-2xl p-6 shadow-sm text-white transition-colors duration-300`}>
          <label className="block mb-3">
            How many meals do you typically have per day?
          </label>
          <div className="flex items-center gap-3 justify-between">
            <Button
              variant="outline"
              size="icon"
              onClick={() => handleDecrement('mealsPerDay')}
              className="h-10 w-10 bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Minus className="h-4 w-4" />
            </Button>
            <div className="flex-1 text-center">
              <span className="text-3xl">{formData.mealsPerDay}</span>
              <span className="text-sm ml-2 text-white/80">meals/day</span>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => handleIncrement('mealsPerDay')}
              className="h-10 w-10 bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Water Intake - Medium Card */}
        <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-2xl p-6 shadow-sm border border-cyan-200">
          <label className="block mb-3 text-cyan-900">
            What is your daily water intake?
          </label>
          <div className="flex items-center justify-center gap-2 mb-2 flex-wrap">
            <button
              onClick={() => setFormData(prev => ({ ...prev, waterIntake: Math.max(0, prev.waterIntake - 1) }))}
              className="flex flex-col items-center transition-all duration-200 hover:scale-110"
            >
              <div className="w-10 h-14 rounded-lg border-2 border-dashed border-cyan-400 bg-cyan-100 flex items-center justify-center hover:bg-cyan-200 hover:border-cyan-500">
                <Minus className="w-5 h-5 text-cyan-600" />
              </div>
            </button>
            {Array.from({ length: Math.max(4, formData.waterIntake) }, (_, index) => index + 1).map((bottleNum) => (
              <button
                key={bottleNum}
                onClick={() => setFormData(prev => ({ 
                  ...prev, 
                  waterIntake: prev.waterIntake === bottleNum ? bottleNum - 1 : bottleNum 
                }))}
                className="flex flex-col items-center transition-all duration-200 hover:scale-110"
              >
                <div className={`w-10 h-14 rounded-lg border-2 flex items-center justify-center transition-colors ${
                  formData.waterIntake >= bottleNum 
                    ? 'bg-cyan-500 border-cyan-600' 
                    : 'bg-white border-cyan-300'
                }`}>
                  <Droplet 
                    className={`w-5 h-5 ${
                      formData.waterIntake >= bottleNum ? 'text-white fill-white' : 'text-cyan-300'
                    }`} 
                  />
                </div>
              </button>
            ))}
            <button
              onClick={() => setFormData(prev => ({ ...prev, waterIntake: Math.max(prev.waterIntake + 1, 5) }))}
              className="flex flex-col items-center transition-all duration-200 hover:scale-110"
            >
              <div className="w-10 h-14 rounded-lg border-2 border-dashed border-cyan-400 bg-cyan-100 flex items-center justify-center hover:bg-cyan-200 hover:border-cyan-500">
                <Plus className="w-5 h-5 text-cyan-600" />
              </div>
            </button>
          </div>
          <div className="text-center text-sm text-cyan-700">
            {formData.waterIntake} L per day
          </div>
        </div>

        {/* Last Meal - Medium Card */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-emerald-100">
          <label className="block mb-3 text-emerald-900">
            What was your last meal?
          </label>
          <div className="flex flex-wrap gap-2 mb-3">
            {foodOptions.map((food) => (
              <button
                key={food.name}
                onClick={() => toggleFood(food.name)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-all duration-200 border ${
                  formData.selectedFoods.includes(food.name)
                    ? 'bg-emerald-500 border-emerald-600 text-white'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                }`}
              >
                <span className="mr-1">{food.emoji}</span>
                {food.name}
              </button>
            ))}
          </div>
          <Input
            placeholder="Or type your custom meal..."
            value={formData.lastMeal}
            onChange={(e) => setFormData(prev => ({ ...prev, lastMeal: e.target.value }))}
            className="border-emerald-200 focus:border-emerald-400 focus:ring-emerald-400"
          />
        </div>

        {/* Additional Info - Smaller Card */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-blue-100">
          <label className="block mb-3 text-blue-900">
            Any additional information?
          </label>
          <Textarea
            placeholder="e.g., existing conditions..."
            value={formData.additionalInfo}
            onChange={(e) => setFormData(prev => ({ ...prev, additionalInfo: e.target.value }))}
            className="min-h-[80px] resize-none border-blue-200 focus:border-blue-400 focus:ring-blue-400"
          />
        </div>

        {/* Medicine Information Button Card */}
        <button
          onClick={() => setSelectedOption(prev => prev === 'medicine' ? null : 'medicine')}
          className={`rounded-2xl p-6 shadow-sm transition-all duration-200 text-left border-2 ${
            selectedOption === 'medicine'
              ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white border-blue-600 shadow-lg scale-105'
              : 'bg-white text-blue-900 border-blue-200 hover:border-blue-400 hover:shadow-md'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <Pill className={`w-8 h-8 ${selectedOption === 'medicine' ? 'text-white' : 'text-blue-600'}`} />
            {selectedOption === 'medicine' && (
              <CheckCircle2 className="w-6 h-6 text-white" />
            )}
          </div>
          <h3 className="mb-1">Medicine Information</h3>
          <p className={`text-sm ${selectedOption === 'medicine' ? 'text-blue-100' : 'text-blue-600'}`}>
            Add medication details
          </p>
        </button>

        {/* Lifestyle Guidance Button Card */}
        <button
          onClick={() => setSelectedOption(prev => prev === 'lifestyle' ? null : 'lifestyle')}
          className={`rounded-2xl p-6 shadow-sm transition-all duration-200 text-left border-2 ${
            selectedOption === 'lifestyle'
              ? 'bg-gradient-to-br from-teal-500 to-teal-600 text-white border-teal-600 shadow-lg scale-105'
              : 'bg-white text-teal-900 border-teal-200 hover:border-teal-400 hover:shadow-md'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <Heart className={`w-8 h-8 ${selectedOption === 'lifestyle' ? 'text-white' : 'text-teal-600'}`} />
            {selectedOption === 'lifestyle' && (
              <CheckCircle2 className="w-6 h-6 text-white" />
            )}
          </div>
          <h3 className="mb-1">Lifestyle Guidance</h3>
          <p className={`text-sm ${selectedOption === 'lifestyle' ? 'text-teal-100' : 'text-teal-600'}`}>
            Share lifestyle habits
          </p>
        </button>
      </div>

      {/* Next Button */}
      <div className="mt-6 flex justify-end">
        <Button 
          size="lg" 
          className="bg-blue-600 text-white hover:bg-blue-700 px-12"
          onClick={handleNext}
        >
          Next
        </Button>
      </div>
    </div>
  );
}